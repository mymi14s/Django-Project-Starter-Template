from django.apps import AppConfig


class SettingConfig(AppConfig):
    name = 'setting'
